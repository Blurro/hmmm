HOW 2 USE??
Drag your mod .pac on top of the exe tool. As if you were dragging it into a folder - don't open the tool and try drag it in the open window.

If it doesn't look right (such as no colors) or you get other errors, install Terminal from Microsoft Store.
If it's still the same, then run as Administrator (and type in your pac name as you can't drag and drop it this way)

You can open versions.txt to change which version is updated/downgraded into which


WHICH .PAC IS IT, IS IT THIS _PC ONE??
It's simply 'playercommon.pac' which is the converted mod file.
The other ones like _PC and _PC_u2 are for the tool to use, you can ignore these.


AHH IT'D BE NICE IF THE TOOL ALSO DID _____
Suggestions are welcome - ping, dm, comment anything!


COOL PRO TIP:::
If you've got an update 2 playercommon mod that modifies the spindash, name it 'playercommon_PC_u2.pac' and move/replace it into this folder.
Then just update an older physics mod through the tool, it'll use this pac and merge with the spindash modifications!